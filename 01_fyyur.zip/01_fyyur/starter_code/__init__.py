from flask import Flask,jsonify

def create_app(test_config=None):
    app=Flask(__name__)
    
    @app.route('/')
    def hello():
        return jsonify({'message':'Hello Nikita'})

    @app.route('/NikVik')
    def NikVik():
        return ('NikVik')

   
    return app